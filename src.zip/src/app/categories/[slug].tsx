import { StyleSheet, Text, View } from 'react-native'
const Category = () => {
  return (
    <View>
      <Text>Category</Text>
    </View>
  )
}
export default Category
const styles = StyleSheet.create({})