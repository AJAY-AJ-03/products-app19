import { StyleSheet, Text, View } from 'react-native'
export default function Auth() {
  return (
    <View>
      <Text>auth</Text>
    </View>
  )
}
const styles = StyleSheet.create({})