import { StyleSheet, Text, View } from 'react-native'
const index = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}
export default index
const styles = StyleSheet.create({})