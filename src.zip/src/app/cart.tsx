import { StyleSheet, Text, View } from 'react-native'
export default function Cart() {
  return (
    <View>
      <Text>Cart</Text>
    </View>
  )
}
const styles = StyleSheet.create({})